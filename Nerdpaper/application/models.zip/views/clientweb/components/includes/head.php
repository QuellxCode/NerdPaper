<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="theme-color" content="#333">
    <meta name="google-site-verification" content="aODjHoKyzOu2e95_5dPUn2azo2vT-HfMUHlQUkuTodM" />
    <title><?php echo $title ?> </title>
    <meta name="description" content="Get premium quality essay writing service at cheaper price. For essay & thesis writing service let an expert writer perform writing services at NerdPapers.">
    <meta name="keywords" content="Essay Writing Service, Thesis Writing Service, Online Writing Services, Write my Essay, Write my Thesis"
    <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/img/titleIcon.png">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/preload.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/plugins.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.light-blue-500.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/width-boxed.min.css" id="ms-boxed" disabled="">
    <!-- Script addition for ajax code  -->
     <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
   
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/sweetalert2@7.22.2/dist/sweetalert2.css">

<style type="text/css">
    select.form-control:not([size]):not([multiple]){
    height: calc(4.25rem + 2px)!important;
}
    .swal2-container.swal2-shown{
        z-index: 1200!important;
    }
</style>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-123281512-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-123281512-1');
</script>


  </head>