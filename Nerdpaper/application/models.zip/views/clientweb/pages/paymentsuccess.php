<div class="container" style="padding:5%;">
	<div class="row">
		<div class="col-md-12 text-center">
			
  <h1 style="color:green; font-family: italic; font-size: 4.6rem !important; font-weight: 500">Congratulations!</h1>
<p style=" font-weight: 600">Your order has been placed successfully.</p>

<p style=" font-weight: 600">If you have any problems please feel free to contact us - we are always pleased to help.</p>



<p style="font-weight: 500; font-size: 2.5rem;">!!! Thank you !!! </p>
		</div>
	</div>
</div>
      <!-- container -->
       <script>
    $(document).ready(function(){
        $('[data-toggle="tooltip"]').tooltip();   
    });
    </script>
    <script>
      (function(i, s, o, g, r, a, m)
      {
        i['GoogleAnalyticsObject'] = r;
        i[r] = i[r] || function()
        {
          (i[r].q = i[r].q || []).push(arguments)
        }, i[r].l = 1 * new Date();
        a = s.createElement(o),
          m = s.getElementsByTagName(o)[0];
        a.async = 1;
        a.src = g;
        m.parentNode.insertBefore(a, m)
      })(window, document, 'script', '../../../../www.google-analytics.com/analytics.js', 'ga');
      ga('create', 'UA-90917746-2', 'auto');
      ga('send', 'pageview');
    </script>

     <script src="<?php echo base_url(); ?>assets/js/plugins.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/app.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/configurator.min.js"></script>
     <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/tooltipBootstrap.css"></link>