<?php

if (!isset($_SESSION['logged_in'])) {
    $data["message"] = 'You are not logged in.';
    redirect('/Order/');

}
?>