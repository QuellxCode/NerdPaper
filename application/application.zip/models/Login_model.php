<?php


class Login_model extends CI_Model
{
    function __construct() {
        parent::__construct();

        $this->load->database();
    }

    // public function insert($data) {
    //     if ($this->db->insert("employee", $data)) {
    //         return true;
    //     }
    // }
    public function get_user($user_email) {

        $this->db->from('users');
        $where = "(user_email='$user_email')";
        $this->db->where($where);
        return $this->db->get()->row();


    }


    
   
}