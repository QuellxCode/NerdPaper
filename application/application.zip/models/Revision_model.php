<?php


class Revision_model extends CI_Model
{
    function __construct() {
        parent::__construct();

        $this->load->database();


    }



    public function all_revision()
    {
       $this->db->select('revisions.*', false);
       $this->db->select('submissions.created_at as submission_date', false);
     
       
       $this->db->from('revisions');
       $this->db->join('submissions', 'submissions.order_id  =  revisions.order_id ', 'inner');
         // $this->db->join('users', 'users.user_id  =  submissions.submission_id ', 'right');


       $this->db->order_by('submissions.submission_id', ' AESC');
       $query_result = $this->db->get();
       $result = $query_result->result();

      

       return $result;
       
   }

   public function get_writer($writerid)
   {
    $this->db->where('user_id',$writerid);
    $data = $this->db->get('users')->row();
    return $data;
}


public function update_revision_status($revisionid)
{

    $column = array('status' => 1);    
    $this->db->where('revision_id', $revisionid);
    $this->db->update('revisions', $column); 
    return true;
}

public function get_all_writer_revisions($writerid)
{

   $multiple = array('writer_id' => $writerid,'status' =>'1');
    $this->db->where($multiple);
    $data = $this->db->get('revisions');
    $result = $data->result();

    return $result;
}

public function save_revised_work($data)
{
    $this->db->insert('revised_work',$data);
    return true;
}


public function change_revision_status($revisionid)
{
    $column = array('status' =>2);    
    $this->db->where('revision_id', $revisionid);
    $this->db->update('revisions', $column); 
    return true;
    
}

public function get_all_revisions_writer($writerid)
{
    $multiple = array('writer_id' => $writerid,'status' =>'1');
    $statustwo = array('writer_id' => $writerid,'status'=>'2');
    $this->db->where($multiple);
    $this->db->or_where($statustwo);
    $data = $this->db->get('revisions');
    $result = $data->result();

    return $result;

}


public function get_revised_work()
{
  $data = $this->db->get('revised_work')->result();
  return $data;
}

public function submit_revised_work_to_client($revisedwork_id)
{
  $column = array('status' =>1);    
    $this->db->where('revised_work_id', $revisedwork_id);
    $this->db->update('revised_work', $column); 
    return true;
}



}