<?php


class Role_model extends CI_Model
{
    function __construct() {
        parent::__construct();

        $this->load->database();
    }

    // public function insert($data) {
    //     if ($this->db->insert("employee", $data)) {
    //         return true;
    //     }
    // }
    public function save_role($data) {

        $this->db->insert('users',$data);
        return true;

    }

    // public function get_region()
    // {
    //     $result = $this->db->get('users');

    //     return $result->result();
    // }

    public function get_roles()
    {
        $result = $this->db->get('users');

      return $result->result();
    }

    public function get_role_byid($id)
    {
        $this->db->where('user_id',$id);
        $result = $this->db->get('users');
        return $result->row();
    }

    public function update_roles($id,$data)
    {
         $this->db->where('user_id',$id);
        $this->db->update('users',$data);
        return true;
    }

    public function delete_role($id)
    {
        $this->db->where('user_id',$id);
        $this->db->delete('users');
        return true;
    }

    
   
}