<?php


class Submission_model extends CI_Model
{
    function __construct() {
        parent::__construct();
        $this->load->database();
    }

    // public function insert($data) {
    //     if ($this->db->insert("employee", $data)) {
    //         return true;
    //     }
    // }

    public function get_submission_detail()
 {
    // $this->db->select('submissions.*', false);
   
    
     $this->db->select('submissions.submission_id', false);
     $this->db->select('submissions.report_file', false);
     $this->db->select('submissions.updated_at', false);
     $this->db->select('submissions.updated_by', false);
    $this->db->select('submissions.created_at as submission_date', false);
     $this->db->select('submissions.status as submission_status', false);
     $this->db->select('submissions.writer_note as writer_submission_note', false);
     $this->db->select('order_details.*', false);
  //  $this->db->select('order_assign as orderassing', false);
        // $this->db->select('users.user_name', false);
        // $this->db->select('users.user_email', false);
    $this->db->from('submissions');
   // $this->db->from('order_assign');

    //$this->db->where('submissions.status', 0);
    
    $this->db->join('order_details', 'order_details.order_detail_id  =  submissions.order_id ', 'left');

      // $this->db->join('order_assign', 'order_assign.order_id  =  order_details.order_detail_id ', 'inner');
   
         // $this->db->join('users', 'users.user_id  =  submissions.submission_id ', 'right');


    $this->db->order_by('submissions.submission_id', ' DESC');
    $query_result = $this->db->get();
    $result = $query_result->result();

    // echo "<pre>";
    // print_r($result);
    // die();

   

    return $result;
}

public function show_submission_to_client($submissionid,$submissionname, $current_datetime)
{
        $column = array('status' => 1,'updated_at'=>$current_datetime, 'updated_by'=>$submissionname);    
    $this->db->where('submission_id', $submissionid);
    $this->db->update('submissions', $column); 
    return true;

}

public function delete_submission($submissionid)
{
    $this->db->where('submission_id',$submissionid);
    $this->db->delete('submissions');
    return true;
}

public function send_half_file($submissionid,$half_file,$submission_datetime)
{

$column = array('status' => 2,'half_file'=>$half_file);    
    $this->db->where('submission_id', $submissionid);
    $this->db->update('submissions', $column); 
    return true;
}

    // public function save_submission($data) {

    //     $this->db->insert('submissions',$data);
    //     return true;

    // }


 //    public function get_submissions()
 //    {
 //     $this->db->where('status',0); 
 //     $data =  $this->db->get('submissions');
 //     $result = $data->result();
 //     return $result;
 // }

 

// public function update_submission($submissionid)
// {
//     $column = array('status' => 1);    
//     $this->db->where('submission_id', $submissionid);
//     $this->db->update('submissions', $column); 
//     return true;
// }

// public function update_order_detail($orderdetail_id)
// {

// $column = array('status' => 2);    
//     $this->db->where('order_detail_id', $orderdetail_id);
//     $this->db->update('order_details', $column); 
//     return true;
// }



}