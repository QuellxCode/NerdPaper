<?php


class Order_model extends CI_Model
{
    function __construct() {
        parent::__construct();
        $this->load->database();
    }

    // public function insert($data) {
    //     if ($this->db->insert("employee", $data)) {
    //         return true;
    //     }
    // }
    // public function get_user($user_email) {

    //     $this->db->from('users');
    //     $where = "(user_email='$user_email')";
    //     $this->db->where($where);
    //     return $this->db->get()->row();


    // }

    // public function orderDelete($orderid) {
    //     if ($this->db->delete("order_details", "order_detail_id = ".$orderid)) {
    //         return true;
    //     }
    // }


    public function get_all_orders()
    {
         $data = $this->db->get('order_details');
         return $data->result();

       //  $this->db->select('order_details.*', false);
       // $this->db->select('order_notes.note_description', false);
       // $this->db->select('order_notes.created_at', false);
       // $this->db->select('order_notes.created_by', false);
     
       
       // $this->db->from('order_details');
       // $this->db->join('order_notes', 'order_notes.order_id  =  order_details.order_detail_id ', 'inner');
       //   // $this->db->join('users', 'users.user_id  =  submissions.submission_id ', 'right');


       // $this->db->order_by('order_details.order_detail_id', ' AESC');
       // $query_result = $this->db->get();
       // $result = $query_result->result();

       // echo "<pre>";
       // print_r($result);
       // die();

    }

    public function chanage_order_status($orderid,$order_status)
    {

        $column = array('order_status' => 1);    
        $this->db->where('order_detail_id', $orderid);
        $this->db->update('order_details', $column); 
        return true;

    }

    public function order_verified_by($verified_by, $verified_at, $order_id)
    {
       $column = array('verified_by' => $verified_by,'verified_at'=>$verified_at);    
       $this->db->where('order_detail_id', $order_id);
       $this->db->update('order_details', $column); 
       return true;

   }




   public function get_single_order($id)
   {
     $this->db->where('order_detail_id',$id);
     $data = $this->db->get('order_details');

     return $data->row();
 }


 public function get_single_order_notes($orderdetailid)
 {
    $this->db->where('order_id',$orderdetailid);
    $data = $this->db->get('order_notes');
    return $data->result();
    // echo "<pre>";
    // print_r($data->result());
    // die();
 }



 public function assign_order_to_writer($data)
 {
    $this->db->insert('order_assign',$data);
    return true;
}


public function assign_order_to_region($data)
 {
    $this->db->insert('order_assign',$data);
    return true;
}


public function update_payment_status($orderid, $paymentstatus)
{
    $column = array('payment_status' => $paymentstatus);    
    $this->db->where('order_detail_id', $orderid);
    $this->db->update('order_details', $column); 
    return true;
}

public function update_order_status($orderid, $orderstatus)
{
    $column = array('order_status' => $orderstatus);    
    $this->db->where('order_detail_id', $orderid);
    $this->db->update('order_details', $column); 
    return true;
}



public function add_note($data)
{
    $this->db->insert('order_notes',$data);
    return true;
}

public function get_singleorder_notes($orderid)
{
    $this->db->where('order_id',$orderid);
    $data = $this->db->get('order_notes');
    return $data->result();
}

public function delete_neworder($orderid)
{
    $this->db->where('order_detail_id',$orderid);
    $this->db->delete();
    return true;

}


public function neworder_update($id,$data)
{
   $this->db->where('order_detail_id',$id);
   $this->db->update('order_details',$data);
   return true;
}


public function check_order_in_assign($orderid)
{
    $this->db->where('order_id',$orderid);
    $this->db->where('status',0);
    $result = $this->db->get('order_assign');
    return $result->num_rows();
}


public function update_assign_order($orderid,$data)
{

    $this->db->where('order_id', $orderid);
    $this->db->update('order_assign', $data); 
    return true;

}

public function get_all_unpaidorders()
{
    $this->db->where('payment_status','0');
    // $unpaid_count = $this->db->count_all_results('order_details');
    $unpaid_data = $this->db->get('order_details');
    $data =  $unpaid_data->result();


    return $data;
    // $myarray = array('count' => $unpaid_count ,'unpaid_data'=>$unpaid_data );
    // return $myarray;

}

public function get_order_inprocess()
{
    $this->db->where('order_status','1');
    // $unpaid_count = $this->db->count_all_results('order_details');
    $inprocess_orders = $this->db->get('order_details');
    $data =  $inprocess_orders->result();

    echo "<pre>";
    print_r($data);
    die();


    return $data;
}

///********* comment**********////////////




public function completed_orders()
{

}



public function unpaid_order_count()
{
    $this->db->where('payment_status','0');
    $unpaid_count = $this->db->count_all_results('order_details');
    return $unpaid_count;
}



public function get_orders_by_region($writer_region_id)
{
    $multiple = array('region_id' => $writer_region_id,'status' =>'0');
    $this->db->where($multiple);
    $data = $this->db->get('order_assign');
    $result = $data->result();
    return $result;

        // echo "<pre>";
        // print_r($result);
        // die();


}

public function accepted_order_writer($id,$writer_id)
{
      //  $this->db->where('order_assign_id',$id);

        //$appointment_id = 0;
    $column = array('status' => 1,'writer_id'=>$writer_id);    
    $this->db->where('order_assign_id', $id);
    $this->db->update('order_assign', $column); 
    return true;
}

public function get_accepted_task($writerid)
{
    $multiple = array('writer_id' => $writerid,'status' =>'1');
    $this->db->where($multiple);
    $data = $this->db->get('order_assign');
    $result = $data->result();

    return $result;
}

public function view_order_for_writer($orderid)
{

    $this->db->where('order_detail_id',$orderid);
    $data = $this->db->get('order_details');
    $result =  $data->row();
    return $result;

}



public function single_order_detail($orderid)
{
    $this->db->where('order_detail_id',$orderid);
    $data = $this->db->get('order_details');
    $result = $data->result();
    return $result;
}

public function update_order_details($orderid, $order_note)
{
    $column = array('order_note' => $order_note);    
    $this->db->where('order_detail_id', $orderid);
    $this->db->update('order_details', $column); 
    return true;

}

public function change_order_status_to_assigned($order_detail_id)
{
    $column = array('status' => 1);    
    $this->db->where('order_detail_id', $order_detail_id);
    $this->db->update('order_details', $column); 
    return true;

}

    // public function update($data,$eid) {
    //     $this->db->set($data);
    //     $this->db->where("eid", $eid);
    //     $this->db->update("employee", $data);
    // }


}