<?php


class Leads_model extends CI_Model
{
    function __construct() {
        parent::__construct();

        $this->load->database();
    }

    // public function insert($data) {
    //     if ($this->db->insert("employee", $data)) {
    //         return true;
    //     }
    // }
    public function all_leads() {

        $data = $this->db->get('leads');
        return $data->result();

    }


    public function lead_statu_db($leadid, $leadstatus)
    {

       
       $column = array('lead_status' => $leadstatus);    
       $this->db->where('lead_id', $leadid);
       $this->db->update('leads', $column); 
       return true;

   

    }

    public function edit_user_lead($leadid)
    {

        $this->db->where('lead_id',$leadid);
        $result = $this->db->get('leads');
        return $result->row();
    }

    public function updatelead($leadid, $data)
    {
        $this->db->where('lead_id',$leadid);
        $this->db->update('leads',$data);
        return true;

    }


    public function insert_lead_note($data)
    {
        $this->db->insert('lead_notes',$data);
        return true;
    }


    
   
}