<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Leads extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()
	{
		parent::__construct();
		$this->load->model('leads_model');
		//$this->load->library('session');

	}


	public function index()
	{
		$data['leads'] =  $this->leads_model->all_leads();

		// echo "<pre>";
		// print_r($data['leads']);
		// die();

		//$this->load->view('admin/pages/leads/show_all_leads',$data);

		$data['breadcrumb'] = 'Leads';
		$data['body_title'] = 'Leads';
		$data['mainview'] = 'admin/pages/leads/show_all_leads';
		$this->load->view('admin/shared/layout',$data);
	}

	public function change_lead_status()
	{

		$leadid = $this->input->post('leadid');
		$leadstatus = $this->input->post('status');

		if($leadstatus == 0)
		{

			$result = $this->leads_model->lead_statu_db($leadid , $leadstatus);
			if($result)
			{
				return 0;
			}

		}else if($leadstatus == 1)
		{ 
			$result =$this->leads_model->lead_statu_db($leadid , $leadstatus);

			if($result)
			{
				return 1;
			}
		}else if($leadstatus == 2)
		{
			$result = $this->leads_model->lead_statu_db($leadid , $leadstatus);

			if($result)
			{
				return 2;
			}
		}else if($leadstatus == 3)
		{
			$result = $this->leads_model->lead_statu_db($leadid , $leadstatus);

			if($result)
			{
				return 3;
			}
		}
		// echo "<pre>";
		// print_r($_POST);
		// die();
	}

	public function add_lead_note()
	{
		// echo "<pre>";
		// print_r($_POST);
		// die();

	$data = array(
		'lead_id' => $this->input->post('leadnoteid'),
		'lead_note' => trim($this->input->post('ordernote'))
	);

	$data = $this->leads_model->insert_lead_note($data);

	if($data)
	{
		redirect('admin/leads','refresh');
	}else{
		echo "not inserted";
	}


	}

	public function edit_lead()
	{
		$editleadid = $this->uri->segment(4);
		//echo $editleadid;

		$data['leads']= $this->leads_model->edit_user_lead($editleadid);

			$data['breadcrumb'] = 'Leads';
		$data['body_title'] = 'Leads';
		$data['mainview'] = 'admin/pages/leads/edit_leads';
		$this->load->view('admin/shared/layout',$data);

	}

	public function update_lead()
	{
		// echo "<pre>";
		// print_r($_POST);
		// die();
		$leadid = $this->input->post('lead_id');
		
		

		$data = array(

			'user_email' => $this->input->post('email'),
			'user_phone' => $this->input->post('phone'),
			'document_type' => $this->input->post('document_type'),
			'no_of_pages' => $this->input->post('no_of_pages'),
			'due_date' => $this->input->post('client_due_date'),

		);

		$result = $this->leads_model->updatelead($leadid,$data);

		if($result)
		{
			redirect('admin/leads','refresh');
		}

		

	// public function change_payment_status()
	// {

	// 	$orderid = $this->input->post('orderid');
	// 	$orderstatus = $this->input->post('status');

	// 	$this->
	// }
}

}