<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Revision extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
        public function __construct()
    {
        parent::__construct();

       $this->load->model('revision_model');
      
        $this->load->library('session');

    }

   public function get_all_revisions()
   {

   $data['revisions'] =  $this->revision_model->all_revision();

   // echo "<Pre>";
   // print_r($data['revisions_list'] );
   // die();

    $data['body_title'] = 'Revisions';
    $data['mainview'] = 'admin/pages/revision/new_revision';
    $this->load->view('admin/shared/layout',$data);
   }


   // public function get_revision_writer()
   // {
   // 	$writerid = $this->uri->segment(3);
   // 	$data['revisionid'] = $this->uri->segment(4);
   // 	$data['writer_detail'] = $this->revision_model->get_writer($writerid);
   	
   // 	$this->load->view('pages/revisions/revision_to_writer',$data);
   // }

//    public function revision_assigned($id)
//    {

// $data = $this->revision_model->update_revision_status($id);
// if($data)
// {
// 	redirect('revision/get_all_revisions','refresh');
// }else{
// 	echo "not updated";
// }

//    }


   // public function writer_latest_revisions()
   // {
   // 		$writerid = $this->uri->segment(3);
   // 		$data['writer_latest_revisions'] = $this->revision_model->get_all_writer_revisions($writerid);

   // 		$this->load->view('pages/revisions/writer_latest_revisions',$data);
   // 		// echo $writerid;
   // 		// die();
   // }


   // public function revised_work()
   // {

  

   // 	$revisionid = $this->input->post('revision_id');

   // 	$data = array(

   // 		'order_id' => $this->input->post('order_id'),
   // 		'writer_id' => $this->input->post('writer_id'),
   // 		'revised_work_file' => 'revisedworkfile.doc',
   // 		'revised_report_file' => 'reportfile.pdf'
   // 	);

   // 	$data = $this->revision_model->save_revised_work($data);
   // 	if($data)
   // 	{
   // 		$changed = $this->revision_model->change_revision_status($revisionid);

   // 		if($changed)
   // 		{
   // 			redirect('revision/writer_latest_revisions','refresh');
   // 		}else{
   // 			echo "not changed";
   // 		}

   // 	}else{
   // 		echo "Revised work not saved";
   // 	}

   // }


// public function all_revisions_writer()
// {
// 	$writerid = $this->uri->segment(3);
	

// 	$data['writer_all_revisions'] = $this->revision_model->get_all_revisions_writer($writerid);
// 	$this->load->view('pages/revisions/writer_all_revisions',$data);
// }

// public function revised_work_admin()
// {
// 	$data['admin_revised_work'] = $this->revision_model->get_revised_work();

// 	$this->load->view('pages/revisions/show_revised_work',$data);

// }


// public function submit_revised_work()
// {
// 	$revised_work_id = $this->uri->segment(3);
	
// 	$result = $this->revision_model->submit_revised_work_to_client($revised_work_id);
// 	if($result)
// 	{
// 		redirect('revision/revised_work_admin','refresh');
// 	}
// }

	
}
