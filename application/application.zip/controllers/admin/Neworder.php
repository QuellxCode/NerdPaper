<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Neworder extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()
	{
		parent::__construct();
		$this->load->model('order_model');
		$this->load->model('region_model');
		$this->load->model('writer_model');
		$this->load->library('session');

	}


	public function index()
	{
		$data['neworders']  = $this->order_model->get_all_orders();
		$data['writers'] = $this->writer_model->get_all_writers();
		$data['regions'] = $this->region_model->get_region();


		$data['body_title'] = 'New Orders';
		$data['mainview'] = 'admin/pages/new_order';
		$this->load->view('admin/shared/layout',$data);
	}

	public function change_payment_status()
	{
		
		$orderid = $this->input->post('orderid');
		$payment_status = $this->input->post('status');

		$result = $this->order_model->update_payment_status($orderid,$payment_status);

		if($result)
		{
			echo "status updated";
		}else{
			echo "note updated";
		}

		//$this->
	}

	public function neworder_verification()
	{	
		$verified_at = date('Y-m-d-h-m-s');

		$orderid = $this->uri->segment(4);
		$writerid = $this->uri->segment(5);

		$username = $this->writer_model->get_single_writer($writerid);
		if($username)
		{
			$result = $this->order_model->order_verified_by($username,$verified_at,$orderid);

			if($result)
			{
				redirect('admin/neworder','refresh');
			}
		}
		
	}

	public function order_detail()
	{
		$orderdetail_id = $this->uri->segment(4);

		$data['neworder_detail'] = $this->order_model->get_single_order($orderdetail_id);

		$data['ordernotes'] = $this->order_model->get_single_order_notes($data['neworder_detail']->order_detail_id);

		

		
		$data['body_title'] = 'Order Detail';
		$data['mainview'] = 'admin/pages/single_order_detail';
		$this->load->view('admin/shared/layout',$data);
	}

	public function assign_order()
	{
		$orderid = $this->input->post('orderid');
		$regionid = $this->input->post('regionid');
		$writerid = $this->input->post('writerid');
		$date = $this->input->post('date');
		$time = $this->input->post('time');
		$duedate =  $date.':'.$time;

		$data = array(

				'order_id' => $orderid,
				'region_id' => $regionid,
				'writer_id' => $writerid,
				'writer_due_date' => $duedate
			);

		$count = $this->order_model->check_order_in_assign($orderid);

		if($count == 1)
		{
			$this->order_model->update_assign_order($orderid,$data);

		}else{

			$this->order_model->assign_order_to_region($data);
		}
		

		
	}

	public function change_order_status()
	{
		$orderid = $this->input->post('orderid');
		$order_status = $this->input->post('status');

		echo $orderid.' '.$payment_status.'<br>';
		//echo $payment_status.'<br>';

		//die();

		$result = $this->order_model->update_order_status($orderid,$order_status);

		if($result)
		{
			echo "status updated";
		}else{
			echo "note updated";
		}
	}

	public function add_order_note()
	{
		$ordernote = $this->input->post('ordernote');
		$orderid = $this->input->post('myorder_id');
		$note_creater = $this->input->post('note_writer');

		$data = array(
			'order_id' => $orderid,
			'note_description' => $ordernote,
			'created_by' => $note_creater 
		);
		$result = $this->order_model->add_note($data);

		if($result)
		{
			//echo "<script>$.notify('Note Addess Successfully', 'success')   </script>";
		}else{
			//echo "note not added";
		}
	}

	public function get_notes()
	{
		$orderid = $this->input->post('orderid');
		$notes = $this->order_model->get_singleorder_notes($orderid);

		echo json_encode($notes);
	}

	public function delete_neworder()
	{
		$val = $this->uri->segment(4);
		//echo $val;

		//$this->order_model->
	}

	public function edit_neworder()
	{
		$orderid = $this->uri->segment(4);
		// echo $myid;
		// die();

		//$this->load->view('admin/pages/edit_new_order');()
		$data['order'] = $this->order_model->get_single_order($orderid);
		// echo "<pre>";
		// print_r($result);
		// die();
		$data['body_title'] = 'Edit Order';
		$data['mainview'] = 'admin/pages/edit_new_order';
		$this->load->view('admin/shared/layout',$data);
	}

	public function update_neworder()
	{
		// echo "<pre>";
		// print_r($_POST);
		// die();
		$orderid = $this->input->post('order_id');
		$data = array(
			'client_email' => $this->input->post('email'),
			'phone' => $this->input->post('phone'),
			'acedamic_level' =>$this->input->post('academic_level'), 
			'document_type' => $this->input->post('document_type'),
			'no_of_pages' => $this->input->post('no_of_pages'),
			'title' => $this->input->post('title'),
			'subject' => $this->input->post('subject'),
			'end_date' => $this->input->post('client_due_date'),
			'end_time' => $this->input->post('client_due_time'),
			'citation_style' => $this->input->post('citation_style'),
			'name_of_sources' => $this->input->post('name_of_sources'),
			'description' => $this->input->post('description')


		);

		$result = $this->order_model->neworder_update($orderid,$data);

		if($result)
		{
			//echo "updated";

			redirect('admin/neworder');
		}else{
			echo "note updated";
		}
		
	}

	public function unpaid_orders()
	{
		$this->order_model->get_all_unpaidorders();
	}

	public function order_inprocess()
	{
		$this->order_model->get_order_inprocess();
	}



	public function test()
	{

		$this->load->view('admin/test');
	}


}
