<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Submission extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
        public function __construct()
    {
        parent::__construct();
       
       $this->load->model('submission_model');
        $this->load->library('session');

    }

    public function get_all_submissions()
    {
      //$data['all_submissions'] = $this->submission_model->get_submissions();
     // $data['all_submissions'] = $this->submission_model->get_submission_detail();

     // $this->load->view('pages/view_submissions',$data);
      $data['submissions_detail'] = $this->submission_model->get_submission_detail();

      // echo "<pre>";
      // print_r($data['submissions_detail']);
      // die();

      $data['body_title'] = 'Submissions';
    $data['mainview'] = 'admin/pages/submission/submission';
    $this->load->view('admin/shared/layout',$data);
      
    }

    public function fullpaid_submission()
    {
      if($this->session->userdata('user_name'))
      {
        $username = $this->session->userdata('user_name');

        $submissionid = $this->uri->segment(4);


        $currentdatetime =   date('Y-m-d H:i:s');      
        // echo $currentdatetime;
        // die();

      $result = $this->submission_model->show_submission_to_client($submissionid,$username,$currentdatetime);

      if($result)
      {
        redirect('admin/submission/get_all_submissions','refresh');
      }
      }
      
    }

    public function halfpaid_submission()
    {
       $data['submissionid'] = $this->uri->segment(4);

        $data['body_title'] = 'Submissions';
    $data['mainview'] = 'admin/pages/submission/halfpaid_submission';
    $this->load->view('admin/shared/layout',$data);

    }


    public function send_half_submissiend_half_submission()
    {
      // echo "<pre>";
      // print_r($_POST);
      // die();

      if ($this->session->userdata('user_name')) {
        $half_submitted_by = $this->session->userdata('user_name');
        $currentdatetime =   date('Y-m-d H:i:s');

        # code...
      }
     $submissionid = $this->input->post('submissionid');
      $half_file = 'halffile.doc';

     $result =  $this->submission_model->send_half_file($submissionid,$half_file,$currentdatetime,$half_submitted_by);

     if($result)
      {
        redirect('admin/submission/get_all_submissions','refresh');
      }

     // echo "Half Submission would get submit";
    }

    public function delete_submission()
    {
     $submissionid = $this->uri->segment(4);

     $result = $this->submission_model->delete_submission($submissionid);

     if($result)
     {
      redirect('admin/submission/get_all_submissions','refresh');
     }

    }

    // public function save_writer_submission()
    // {
      
    //   $assignmentid = $this->input->post('assignment_id');
    //   $orderid = $this->input->post('order_id');

    //   $data = array(

    //     'order_id'=> $orderid,
    //     'writer_id'=> $this->input->post('writer_id'),
    //     'work_file'=> 'Work File.doc',
    //     'report_file'=> 'Report File.doc'
    //   );

    //   $data = $this->submission_model->save_submission($data);

    //   if($data)
    //   {


    //    $result =  $this->submission_model->update_order_detail($orderid);
    //    if($result)
    //    {
    //     redirect('home/orderList','refresh');
    //    }
    //     //echo "Successfully saved submission";
        
    //   }else{

    //     echo "Submission note saved";
    //   }


    //   // echo "<pre>";
    //   // print_r($_POST);
    //   // die();

    // }


    

    // public function view_writer_submission()
    // {

    //   $orderid = $this->uri->segment(3);


    //   $data['submission_detail'] = $this->submission_model->get_submission_detail($orderid);
    //   $this->load->view('pages/submissions/submission_detail',$data);

    // }


    // public function submission_submitted()
    // {
    //   $submissionid = $this->uri->segment(3);
    //   $data = $this->submission_model->update_submission($submissionid);
    //   if($data)
    //   {
    //     redirect('submission/get_all_submissions');
    //   }else{
    //     echo "not updated";
    //   }
    // }
   

   



	
}
