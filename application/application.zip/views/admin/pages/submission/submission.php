<meta charset="utf-8" />
<title>Metronic Admin Theme #3 | Editable Datatables</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta content="width=device-width, initial-scale=1" name="viewport" />
<meta content="Preview page of Metronic Admin Theme #3 for editable datatable samples" name="description" />
<meta content="" name="author" />
<!-- BEGIN GLOBAL MANDATORY STYLES -->
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url(); ?>assets_material/assets/global/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url(); ?>assets_material/assets/global/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url(); ?>assets_material/assets/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url(); ?>assets_material/assets/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css" />
<!-- END GLOBAL MANDATORY STYLES -->
<!-- BEGIN PAGE LEVEL PLUGINS -->
<link href="<?php echo base_url(); ?>assets_material/assets/global/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url(); ?>assets_material/assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.css" rel="stylesheet" type="text/css" />
<!-- END PAGE LEVEL PLUGINS -->
<!-- BEGIN THEME GLOBAL STYLES -->
<link href="<?php echo base_url(); ?>assets_material/assets/global/css/components.min.css" rel="stylesheet" id="style_components" type="text/css" />
<link href="../assets/global/css/plugins.min.css" rel="stylesheet" type="text/css" />
<!-- END THEME GLOBAL STYLES -->
<!-- BEGIN THEME LAYOUT STYLES -->
<link href="<?php echo base_url(); ?>assets_material/assets/layouts/layout3/css/layout.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url(); ?>assets_material/assets/layouts/layout3/css/themes/default.min.css" rel="stylesheet" type="text/css" id="style_color" />
<link href="<?php echo base_url(); ?>assets_material/assets/layouts/layout3/css/custom.min.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets_material/countdown/css/jquery.countdown.css"> 

<!-- END THEME LAYOUT STYLES -->
<!-- END PAGE LEVEL PLUGINS -->

<div class="row">
  <div class="col-md-12">
    <!-- BEGIN EXAMPLE TABLE PORTLET-->
    <div class="portlet light portlet-fit ">
      <div class="portlet-title">
        <div class="caption">
          <i class="icon-settings font-red"></i>
          <span class="caption-subject font-red sbold uppercase">All Submissions</span>
        </div>
                <!-- <div class="actions">
                    <div class="btn-group btn-group-devided" data-toggle="buttons">
                        <label class="btn btn-transparent red btn-outline btn-circle btn-sm active">
                            <input type="radio" name="options" class="toggle" id="option1">Actions</label>
                            <label class="btn btn-transparent red btn-outline btn-circle btn-sm">
                                <input type="radio" name="options" class="toggle" id="option2">Settings</label>
                            </div>
                          </div> -->
                        </div>
                        <div class="portlet-body">
                          <div class="table-toolbar">
                            <div class="row">
                              <div class="col-md-6">
                                <div class="btn-group">
                                        <!-- <button id="sample_editable_1_new" class="btn green"> Add New
                                            <i class="fa fa-plus"></i>
                                          </button> -->
                                        </div>
                                      </div>
                                      <div class="col-md-6">
                                        <div class="btn-group pull-right">
                                        <!-- <button class="btn green btn-outline dropdown-toggle" data-toggle="dropdown">Tools
                                            <i class="fa fa-angle-down"></i>
                                          </button> -->
                                          <ul class="dropdown-menu pull-right">
                                            <li>
                                              <a href="javascript:;"> Print </a>
                                            </li>
                                            <li>
                                              <a href="javascript:;"> Save as PDF </a>
                                            </li>
                                            <li>
                                              <a href="javascript:;"> Export to Excel </a>
                                            </li>
                                          </ul>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <table class="table table-striped table-hover table-bordered" id="submission_tbl">
                                    <thead>
                                      <tr>
                                        <th width="1%"> Sr# </th>
                                        <th width="1%"> Order Id </th>
                                        <th width="1%"> Cust Name </th>
                                        <th width="1%"> Payment </th>
                                        <th width="1%">P# </th>
                                        <th width="1%"> Writer Name </th>
                                        <th width="1%">Writer Due Date</th>
                                        <th width="1%"> Submission Date </th>
                                        <th width="1%">Uploads</th>
                                        <th width="1%">Writer Document Note</th>
                                        <th width="1%"> Bonus / Deduction </th>

                                        <th width="1%">Action</th>
                                        <th width="1%">Assigned By & Date</th>
                                        <th width="1%">Submitted by</th>
                                        <th width="1%">Quality</th>
                                        <th width="1%">Add Note</th>
                                        <th width="1%">Chargebacks</th>
                                        <th width="1%">Client feedback</th>
                                        <th width="1%">Delete</th>

                                      </tr>
                                    </thead>
                                    <tbody>

                                     <?php 
                                     $i = 1;
                                     $count = 0;
                                     foreach ($submissions_detail as $key => $submission):
                                      ?>
                                      <?php $count++ ?>

                                      <tr>

                                        <td> 

                                         <?php echo $count ?> </td>
                                         <td> NDP-1550 </td>
                                         <td> customer name </td>
                                         <td>  

                                          <?php
                                          if($submission->payment_status == 0){
                                            echo '<span class="label label-danger">UnPaid</span>';
                                          }elseif($submission->payment_status == 1){
                                            echo '<span class="label label-warning">Half Paid</span>';
                                          }elseif($submission->payment_status == 2){
                                            echo '<span class="label label-info">Full Paid</span>';
                                          }
                                          ?>

                                        </td>
                                        <td> 
                                          <?php echo $submission->no_of_pages ?>
                                        </td>
                                        <td class="center"> <?php 
                                        echo 'writer name shown';

                                        ?> </td>

                                        <td>
                                         <!--  <?php 
                                          echo $submission->wr_duedate;

                                          ?> -->

                                          wr due date

                                        </td>

                                        <td>

                                          <?php echo $submission->submission_date ?>


                                        </td>

                                        <td>

                                          <?php echo 'work_file'.'<br>'; ?>
                                          <?php echo 'Report File'.'<br>'; ?>

                                        </td>
                                        <td>
                                          <?php 
                                          echo $submission->writer_submission_note;
                                          ?>
                                        </td>

                                        <td>
                                         <?php echo 'add-ded'; ?>

                                       </td>

                                       <td>
                                        <a href="">MR
                                           <i class="icon-check"></i>
                                        </a>
                                        <br>
                                        <?php if ($submission->payment_status ==2): ?>
                                        

                                            <?php if ($submission->submission_status == 1): ?>

                                              <?php echo "submitted full<br> by <br>".' '.$submission->updated_by.'<br> '.' on'.' '.$submission->updated_at ?>                                           

                                            <?php else: ?>



                                                <a href="<?php echo base_url(); ?>index.php/admin/submission/fullpaid_submission/<?php echo $submission->submission_id ?>"><button class="btn btn-success" style="border-radius: 3px,3px,3px,3px;">Submit Final <br> Copy  to <br> Client</button></a>
                                              
                                            <?php endif ?>

                                        <?php else: ?>

                                          <?php if ($submission->submission_status == 2): ?>

                                            <?php echo "submitted half<br> by <br>".' '.$submission->updated_by.'<br> '.' on'.' '.$submission->updated_at ?>

                                          <?php else: ?>

                                               <a href="<?php echo base_url(); ?>index.php/admin/submission/halfpaid_submission/<?php echo $submission->submission_id ?>" target="_blank"><button class="btn btn-danger" style="border-radius: 3px,3px,3px,3px;">Submit Half <br> Copy  to <br> Client</button></a>

                                            
                                          <?php endif ?>


                                       

                                        <?php endif; ?>
                                      </td>

                                      <td>
                                       assigned by and date
                                     </td>
                                     <td>something</td>
                                     <td>
                                       thumbs up or down
                                     </td>

                                     <td>
                                       add note submission
                                     </td>

                                     <td>Chargebacks</td>
                                     <td>Client feedback</td>



                                     <td>
                                                                 <!--  <a class="btn btn-circle btn-icon-only btn-default" href="">
                                           <i class="icon-pencil"></i>
                                         </a> -->

                                         <a  href="<?php echo base_url(); ?>index.php/admin/submission/delete_submission/<?php echo $submission->submission_id ?>" class="btn btn-circle btn-icon-only btn-danger" href="">
                                           <i class="icon-trash"></i>
                                         </a>
                                       </td>



                                                                        <!-- <td>
                                                                          
                                                                        </td> -->


                                                                        <!--   <td>
                                                                             
                                                                        </td> -->
                                                                    <!-- <td>
                                                                        <a class="edit" href="javascript:;"> Edit </a>
                                                                      </td> -->
                                                                    <!-- <td>
                                                                        <a class="delete" href="javascript:;"> Delete </a>
                                                                      </td> -->
                                                                    </tr>






                                                                    <?php 
                                                                    $i++;

                                                                    endforeach ?>

                                                                  </tbody>
                                                                </table>
                                                              </div>
                                                            </div>
                                                            <!-- END EXAMPLE TABLE PORTLET-->
                                                          </div>
                                                        </div>

                                                        <!-- Modal -->

                                                        <div class="modal fade" id="addNote" role="dialog">
                                                          <div class="modal-dialog">

                                                            <!-- Modal content-->
                                                            <div class="modal-content">
                                                              <div class="modal-header">
                                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                                <h4 style="color:red;"><span class="glyphicon glyphicon-lock"></span> Add Note</h4>
                                                              </div>
                                                              <div class="modal-body">
                                                                <form role="form" method="post" action="<?php echo base_url(); ?>index.php/admin/neworder/add_order_note">

                                                                  <div class="form-group" id="mytextarea"> 
                                                                    <label>Add Note</label>    
                                                                    <textarea class="form-control" name="ordernote">

                                                                    </textarea>
                                                                    <input type="hidden" name="myorder_id" id="orderid" />
                                                                    <input type="hidden" name="note_writer" id="note_writer" />
                                                                  </div>



                                                                  <button type="submit" class="btn btn-default btn-success btn-block"><span class="glyphicon glyphicon-off"></span> Add</button>
                                                                </form>
                                                              </div>
                                                              <div class="modal-footer">
                                                                <button type="submit" class="btn btn-default btn-default pull-left" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>

                                                              </div>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <!-- EndModal -->

                                                        <!-- Modal -->

                                                        <div class="modal fade mynotemodal"  role="dialog" style="display: none">
                                                          <div class="modal-dialog">

                                                            <!-- Modal content-->
                                                            <div class="modal-content">
                                                              <div class="modal-header">
                                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                                <h4 style="color:red;"><span class="glyphicon glyphicon-lock"></span> Notes List</h4>
                                                              </div>
                                                              <div class="modal-body">
                                                                <table class="table table-hover">
                                                                  <thead>
                                                                    <th>Note id</th>
                                                                    <th>Note Description</th>
                                                                    <th>Created By</th>
                                                                    <th>Date</th>
                                                                  </thead>
                                                                  <tbody id="noteid">



                                                                  </tbody>
                                                                </table>
                                                                <p id="modalbody"> </p>
                                                              </div>
                                                              <div class="modal-footer">
                                                                <button type="submit" class="btn btn-default btn-default pull-left" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>

                                                              </div>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <!-- EndModal -->


                                                        <!-- BEGIN CORE PLUGINS -->
                                                        <!-- <script src="<?php echo base_url(); ?>assets_material/assets/global/plugins/jquery.min.js" type="text/javascript"></script> -->
                                                        <script type="text/javascript" src="<?php echo base_url(); ?>assets_material/date/build/jquery.datetimepicker.full.min"></script>
                                                        <script src="<?php echo base_url(); ?>assets_material/assets/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
                                                        <script src="<?php echo base_url(); ?>assets_material/assets/global/plugins/js.cookie.min.js" type="text/javascript"></script>
                                                        <script src="<?php echo base_url(); ?>assets_material/assets/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
                                                        <script src="<?php echo base_url(); ?>assets_material/assets/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
                                                        <script src="<?php echo base_url(); ?>assets_material/assets/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
                                                        <!-- END CORE PLUGINS -->
                                                        <!-- BEGIN PAGE LEVEL PLUGINS -->
                                                        <script src="<?php echo base_url(); ?>assets_material/assets/global/scripts/datatable.js" type="text/javascript"></script>
                                                        <script src="<?php echo base_url(); ?>assets_material/assets/global/plugins/datatables/datatables.min.js" type="text/javascript"></script>
                                                        <script src="<?php echo base_url(); ?>assets_material/assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js" type="text/javascript"></script>
                                                        <!-- END PAGE LEVEL PLUGINS -->
                                                        <!-- BEGIN THEME GLOBAL SCRIPTS -->
                                                        <script src="<?php echo base_url(); ?>assets_material/assets/global/scripts/app.min.js" type="text/javascript"></script>
                                                        <!-- END THEME GLOBAL SCRIPTS -->
                                                        <!-- BEGIN PAGE LEVEL SCRIPTS -->
                                                        <script src="<?php echo base_url(); ?>assets_material/assets/pages/scripts/table-datatables-editable.js" type="text/javascript"></script>
                                                        <!-- END PAGE LEVEL SCRIPTS -->
                                                        <!-- BEGIN THEME LAYOUT SCRIPTS -->
                                                        <script src="<?php echo base_url(); ?>assets_material/assets/layouts/layout3/scripts/layout.min.js" type="text/javascript"></script>
                                                        <script src="<?php echo base_url(); ?>assets_material/assets/layouts/layout3/scripts/demo.min.js" type="text/javascript"></script>
                                                        <script src="<?php echo base_url(); ?>assets_material/assets/layouts/global/scripts/quick-sidebar.min.js" type="text/javascript"></script>
                                                        <script src="<?php echo base_url(); ?>assets_material/assets/layouts/global/scripts/quick-nav.min.js" type="text/javascript"></script>
                                                        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>   

                                                        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
                                                        <script type="text/javascript" src="<?php echo base_url() ?>assets_material/countdown/js/jquery.plugin.js"></script> 
                                                        <script type="text/javascript" src="<?php echo base_url() ?>assets_material/countdown/js/jquery.countdown.js"></script>  


                                                        <!-- END THEME LAYOUT SCRIPTS -->
                                                        <!-- END PAGE LEVEL PLUGINS -->

        <!-- <script type="text/javascript">
            var myTable = $('#sample_editable_1').DataTable();
 
myTable.row( ':eq(0)' ).edit( {
    title: 'Edit first row'
} );
</script> -->

<script type="text/javascript">
  $(document).ready(function(){ $('#mytbl').DataTable({
   "scrollX": true,


 });
// $('#sample_editable_1').DataTable( {
//         "scrollX":        "true",
//         "scrollCollapse": true,
//         "paging":         false
//     } );

});

</script>



<script type="text/javascript">
  function payment_status($id,$value)
  {
    var row = $value
    var myvalue =  $('#mystatus'+row).val();
    alert(myvalue);
        //alert($id);
          //  alert('working'.$id);
          $.ajax({
           type: "POST",
           url: "neworder/change_payment_status", 
           data: {orderid: $id, status : myvalue},
           dataType: "text",  
           cache:false,
           success: 
           function(data){
                alert(data);  //as a debugging message.
              }
            });
        }




      </script>

      <script type="text/javascript">
        function order_status($orderid,$value)
        {
        //alert("orderstatus called");
        var row = $value;
        var myvalue =  $('#orderstatus'+row).val();
      // debugger;
        //alert(myvalue);
       // alert($id);
          //  alert('working'.$id);
          //debugger;
          $.ajax({
           type: "POST",
           url: "neworder/change_order_status", 
           data: {orderid: $orderid, status : myvalue},
           dataType: "text",  
           cache:false,
           success: 
           function(data){
               // alert(data);  //as a debugging message.
             }
           });
        }
      </script>

        <!-- <script type="text/javascript">
   $('.datepicker').datepicker({
    format: 'dd/mm/yyyy'
 });
</script> -->


<!-- <script type="text/javascript">
    $(".form_datetime").datetimepicker({format: 'yyyy-mm-dd hh:ii'});
  </script>  -->
  <script>
    $(document).ready(function(){
      $('[data-toggle="tooltip"]').tooltip(); 
    });
  </script>

  <script type="text/javascript">
    function assign($orderid,$rowid)
    {

      var value = $rowid;
        //alert("working");

       //alert(writer)

       if(region == -1 && writer == -1)
       {
        alert('not selected');
      }else 
      {


        // var limit = "<?php echo $i; ?>";
        //  alert(limit-1);

        // alert('working');
        debugger;
        var region =  $('#region_list'+value).val();
        var writer =  $('#writer_list'+value).val();
        var date = $("#writer_due_date"+value).val();
        var time = $("#writer_due_time"+value).val();
          //  alert('working'.$id);
          $.ajax({
           type: "POST",
           url: "neworder/assign_order", 
           data: {orderid: $orderid, regionid : region,writerid : writer, date:date,time:time},
           dataType: "text",  
           cache:false,
           success: 
           function(data){
                alert(data);  //as a debugging message.
                $('#region_list  option[value=region]').prop("selected", true);
              }
            });
        }
       //alert(region.' '.date);
     }
   </script>

   <script type="text/javascript">
    // $("#regionlist").onchange(function(){

    // })
  </script>

  <script type="text/javascript">
    $("#timers").countdown({until: new Date(2018, 4-1, 6)});
  </script>

  <script>
    $('#addNote').on('show.bs.modal', function(e) {

      var $modal = $(this),
      orderid_note = e.relatedTarget.id;

      $("#orderid").val(orderid_note);


    })
  </script>

  <script>
    $('#addNote').on('show.bs.modal', function(e) {

      var $modal = $(this),
      note_writer = e.relatedTarget.name;

      $("#note_writer").val(note_writer);


    })
  </script>

  <script type="text/javascript">
    function viewnotes($orderid,$count)
    {
      var value = $count;
       // $('.mynotemodal').attr('id').val(4);
       // $('#notes').modal('hide');
       $(".mynotemodal").attr("id", "notes"+value);

       $.ajax({
         type: "POST",
         url: "neworder/get_notes", 
         data: {orderid: $orderid},
         dataType: "text",  
         cache:false,
         success: 
         function(data){

            //alert(data['note_id']);

            var result  = jQuery.parseJSON(data);
         // alert(result.note_id);
         $.each(result,function(index,value){

    //alert(value.attr("note_id"));

    // $.each(value,function(index,value){



    //  });

    //alert(value['note_id']);



    $("#noteid").append("<tr id='mytbl'><td>"+ value['note_id']+"</td> <td>"+value['note_description']+" </td> <td> "+value['created_by']+" </td> <td>"+value['created_at']+"</td></tr>");
  });

// $("#modalbody").append("hi its working");


 //$("#addNote").empty();
           //alert(result.);
            // var data = $.parseJSON(data);
            //     alert(data);  //as a debugging message.

            // $.each(data, function(index, element) {
            //     alert(element);
            // $('#mytextarea').html(element);
            //    ("#addNote").modal('show');
            // }
          }
        });
     }
   </script>

   <script type="text/javascript">
    $("#neworder_tbl").DataTable();
  </script>

  <script type="text/javascript">

  </script>

  <script type="text/javascript">
    // function showcalender($count)
    // {
    //     debugger;
    //     var value = $count;

       // jQuery('#datetimepicker').datetimepicker();

    // }
  </script>

  <script type="text/javascript">
    jQuery('#datetimepicker').datetimepicker({

 //format:'dd.m.YY'
 
});
</script>