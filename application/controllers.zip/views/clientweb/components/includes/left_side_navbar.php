    <div class="ms-slidebar sb-slidebar sb-left sb-style-overlay" id="ms-slidebar">
      <div class="sb-slidebar-container">
        <header class="ms-slidebar-header">
          <div class="ms-slidebar-login">
             <a class="withripple" data-toggle="modal" data-target="#ms-account-modal">
              <i class="zmdi zmdi-account"></i> Login</a>
            <a class="withripple" data-toggle="modal" data-target="#register">
              <i class="zmdi zmdi-account-add"></i> Register</a>
          </div>
          <div class="ms-slidebar-title">
            <form class="search-form">
              <input id="search-box-slidebar" type="text" class="search-input" placeholder="Search..." name="q" />
              <label for="search-box-slidebar">
                <i class="zmdi zmdi-search"></i>
              </label>
            </form>
            <div class="ms-slidebar-t">
             
              <h3>NerdPapers
                
              </h3>
            </div>
          </div>
        </header>
         <ul class="ms-slidebar-menu" id="slidebar-menu" role="tablist" aria-multiselectable="true">
              <li class="nav-item dropdown active">
                <a  href="<?php echo base_url(); ?>index.php/home" class="nav-link active">Home
                  <!-- <i class="zmdi zmdi-chevron-down"></i> -->
                </a>

              </li>
              <li class="nav-item dropdown">
                <a  href="<?php echo base_url(); ?>index.php/writer" class="nav-link">Our writers
                 <!--  <i class="zmdi zmdi-chevron-down"></i> -->
                </a>


              </li>
              <li class="nav-item dropdown dropdown-megamenu-container">
                <a  href="<?php echo base_url(); ?>index.php/faq" class="nav-link ">Faqs
                 <!--  <i class="zmdi zmdi-chevron-down"></i> -->
                </a>
              </li>

              <li class="nav-item dropdown">
                <a  href="<?php echo base_url(); ?>index.php/order" class="nav-link">Order
                  <!-- <i class="zmdi zmdi-chevron-down"></i> -->
                </a>
              </li>

              <li class="nav-item dropdown">
                <a  href="<?php echo base_url(); ?>index.php/pricing" class="nav-link">Pricing
                  <!-- <i class="zmdi zmdi-chevron-down"></i> -->
                </a>
              </li>

              <li class="nav-item dropdown">
                <a  href="<?php echo base_url(); ?>index.php/aboutus" class="nav-link">About Us
                  <!-- <i class="zmdi zmdi-chevron-down"></i> -->
                </a>
              </li>

            </ul>
        <div class="ms-slidebar-social ms-slidebar-block">
          <h4 class="ms-slidebar-block-title">Social Links</h4>
          <div class="ms-slidebar-social">
            <a href="javascript:void(0)" class="btn-circle btn-circle-raised btn-facebook">
              <i class="zmdi zmdi-facebook"></i>
              <span class="badge-pill badge-pill-pink">12</span>
              <div class="ripple-container"></div>
            </a>
            <a href="javascript:void(0)" class="btn-circle btn-circle-raised btn-twitter">
              <i class="zmdi zmdi-twitter"></i>
              <span class="badge-pill badge-pill-pink">4</span>
              <div class="ripple-container"></div>
            </a>
            <a href="javascript:void(0)" class="btn-circle btn-circle-raised btn-google">
              <i class="zmdi zmdi-google"></i>
              <div class="ripple-container"></div>
            </a>
            <a href="javascript:void(0)" class="btn-circle btn-circle-raised btn-instagram">
              <i class="zmdi zmdi-instagram"></i>
              <div class="ripple-container"></div>
            </a>
          </div>
        </div>
      </div>
    </div>