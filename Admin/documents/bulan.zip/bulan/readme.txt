= Credit =
- Bulan is based off Underscores http://underscores.me/, (C) 2012-2015 Automattic, Inc.
- Hybrid folder is based off Hybrid Core part http://themehybrid.com/hybrid-core, (C) 2010-2015 Justin Tadlock.
- Customizer library by Devin Price under GPL, https://github.com/devinsays/customizer-library

= Useful Links =
- Documentation: http://docs.theme-junkie.com/bulan
- Twitter      : https://twitter.com/theme_junkie
- Facebook     : https://www.facebook.com/themejunkies
